const redis = require('redis');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3002;  


// Redis Cloud credentials
const redisHost = 'redis-13224.c327.europe-west1-2.gce.cloud.redislabs.com';
const redisPort = 13224;
const redisPassword = 'Data12345';
const redisUsername = 'default';

// Create a Redis client
const redisClient = redis.createClient({
    url: `redis://${redisUsername}:${redisPassword}@${redisHost}:${redisPort}`
});

module.exports = redisClient;


app.use(bodyParser.json());

const client = redis.createClient();

// Handle connection errors
client.on('error', (err) => {
  console.error(`Redis connection error: ${err}`);
});

// Create (POST) - Add a new resource
app.post('/api/books', (req, res) => {
  const { title, author, isbn } = req.body;

  // Validate input
  if (!title || !author || !isbn) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  // Generate a unique ID (for simplicity, using a timestamp)
  const id = Date.now();

  // Create a new book object
  const newBook = { id, title, author, isbn };

  // Save the book to Redis
  client.hset('books', id, JSON.stringify(newBook), (err, reply) => {
    if (err) {
      console.error(`Error adding book: ${err}`);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(201).json(newBook);
    }
  });
});

// Read (GET) - Retrieve all books
app.get('/api/books', (req, res) => {
  client.hvals('books', (err, data) => {
    if (err) {
      console.error(`Error retrieving books: ${err}`);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      const books = data.map((book) => JSON.parse(book));
      res.status(200).json(books);
    }
  });
});

// Update (PUT) - Modify book information
app.put('/api/books/:id', (req, res) => {
  const { id } = req.params;
  const { title, author, isbn } = req.body;

  // Validate input
  if (!title && !author && !isbn) {
    return res.status(400).json({ error: 'No fields to update' });
  }

  // Check if the book exists
  client.hexists('books', id, (err, exists) => {
    if (err) {
      console.error(`Error checking book existence: ${err}`);
      return res.status(500).json({ error: 'Internal Server Error' });
    }

    if (!exists) {
      return res.status(404).json({ error: 'Book not found' });
    }

    // Update the book in Redis
    const updatedFields = {};
    if (title) updatedFields.title = title;
    if (author) updatedFields.author = author;
    if (isbn) updatedFields.isbn = isbn;

    client.hset('books', id, JSON.stringify(updatedFields), (err, reply) => {
      if (err) {
        console.error(`Error updating book: ${err}`);
        res.status(500).json({ error: 'Internal Server Error' });
      } else {
        res.status(200).json({ message: 'Book updated successfully' });
      }
    });
  });
});

// Delete (DELETE) - Remove a book from the catalog
app.delete('/api/books/:id', (req, res) => {
  const { id } = req.params;

  // Delete the book from Redis
  client.hdel('books', id, (err, reply) => {
    if (err) {
      console.error(`Error deleting book: ${err}`);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.status(204).send();
    }
  });
});

app.listen(PORT, () => {
  console.log(`Microservice is running on http://localhost:${PORT}`);
});