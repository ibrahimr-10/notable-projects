

const express = require ("express") 
const app = express()
const PORT = 3001 
app.use(express.json())

app.get("/book", (req, res, next) => {
    res.send("Hello GET from the API books!!!!!!!!")
})

app.get("/book2", (req, res, next) => {
    res.send("Hello GET from (book2) the API books!!!!!!!!")
}) 

app.post("/book", (req, res, next) => {
    // Handle the POST request logic here
    const newBook = req.body;
    // Add logic to save the new book to your data storage or perform other actions
    res.json(newBook);
})

app.put("/book/:id", (req, res, next) => {
    const bookId = req.params.id;
    const updatedBook = req.body;
    // Add logic to update the book with the specified ID
    res.json({ message: `Book with ID ${bookId} updated successfully!` });
});

app.delete("/book/:id", (req, res, next) => {
    const bookId = req.params.id;
    // Add logic to delete the book with the specified ID
    res.json({ message: `Book with ID ${bookId} deleted successfully!` });
});


app.listen(PORT, () => {
    console.log("API book server has started on port " + PORT)
})



