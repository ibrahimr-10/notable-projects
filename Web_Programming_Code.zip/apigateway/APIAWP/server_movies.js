const express = require("express");
const app = express();
const PORT = 3003; // Using a different port for the Movies microservice
app.use(express.json());

// GET request to retrieve data
app.get("/api/movies", (req, res) => {
    res.json({ message: "GET request to retrieve movie data" });
});

// POST request to create a new resource
app.post("/api/movies", (req, res) => {
    const { title, director, genre } = req.body;
    res.json({ message: "POST request to create a new movie resource" });
});

// PUT request to update a resource
app.put("/api/movies/:id", (req, res) => {
    const { id } = req.params;
    res.json({ message: `PUT request to update movie resource with id ${id}` });
});

// GET request to retrieve all movies
app.get("/api/movies/all", (req, res) => {
    res.json({ message: "GET request to retrieve all movies" });
});

// DELETE request to remove a resource
app.delete("/api/movies/:id", (req, res) => {
    const { id } = req.params;
    res.json({ message: `DELETE request to remove movie resource with id ${id}` });
});

app.listen(PORT, () => {
    console.log("Movies microservice is running on http://localhost:" + PORT);
});
