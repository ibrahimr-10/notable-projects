const express = require("express");
const router = express.Router();
const axios = require("axios");
const registry = require("./registry.json");
const fs = require("fs");

router.get("/apigateway", (req, res) => {
  const url = req.url;
  res.send(`Requested URL: ${url}`);
});

router.post("/enable/:API_HU", (req, res) => {
  const API = req.params.API_HU;
  const requestBody = req.body;
  const instances = registry.services[API].instances;
  const index = instances.findIndex((srv) => srv.url === requestBody.url);

  if (index === -1) {
    res.send({
      status: "error",
      message: `Could not find '${requestBody.url}' for service '${API}'`,
    });
  } else {
    instances[index].enabled = requestBody.enabled;
    fs.writeFile("./routes/registry.json", JSON.stringify(registry), (error) => {
      if (error) {
        res.send(
          `Could not enable/disable '${requestBody.url}' for service '${API}':\n${error}`
        );
      } else {
        res.send(
          `Successfully enabled/disabled '${requestBody.url}' for service '${API}'\n`
        );
      }
    });
  }
});

router.all("/:API_HU/*", (req, res) => {
  const { API_HU } = req.params;
  const path = req.params[0] || ''; // Get the path from the URL

  if (registry.services[API_HU]) {
    axios
      .get(registry.services[API_HU].url + path)
      .then((response) => {
        res.send(response.data);
      })
      .catch((error) => {
        console.error(`Error making request to ${API_HU}: ${error.message}`);
        res.status(500).send(`Internal Server Error: ${error.message}`);
      });
  } else {
    res.status(404).send(`API not found: ${API_HU}`);
  }
});

router.post("/register", (req, res) => {
  const regInfo = req.body;

  regInfo.url = req.protocol + "://" + regInfo.host + ":" + regInfo.port + "/";

  if (APIExist(regInfo)) {
    res.send(`Config exists for ${regInfo.API_HU} at ${regInfo.url}`);
  } else {
    registry.services[regInfo.API_HU].instances.push({ ...regInfo });

    fs.writeFile("./routes/registry.json", JSON.stringify(registry), (error) => {
      if (error) {
        res.send(`Could not register service: ${error}`);
      } else {
        res.send(`Successfully registered service: ${regInfo.API_HU}`);
      }
    });
  }
});

module.exports = router;
