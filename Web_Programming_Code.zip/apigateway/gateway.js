const express = require("express")
const app = express ()
const PORT = 3000 
const registry = require('./routes/registry.json');


const routes = require("./routes")

app.use(express.json())
app.use("/", routes)

app.listen(PORT, () => {
    console.log("My Gate way has started  on port " + PORT)
})

const auth = (req, res, next) => {
    const url = req.protocol + '://' + req.hostname + PORT + req.path;
    const authString = Buffer.from(req.headers.authorization, "base64").toString("utf8");
    const authParts = authString.split(':');
    const username = authParts[0];
    const password = authParts[1];
    const user = registry.auth.users[username];

    if (user) {
        if (user.username === username && user.password === password) {
            next();
        } else {
            res.send({ authenticated: false, path: url, message: "Authentication Unsuccessful: Incorrect password." });
        }
    } else {
        res.send({ authenticated: false, path: url, message: "Authentication Unsuccessful: User " + username + " doesn't exist." });
    }
};

app.use(auth);
